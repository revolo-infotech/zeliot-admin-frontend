function getAccountType() {
  return localStorage.getItem('Account_type')
}

export default getAccountType
