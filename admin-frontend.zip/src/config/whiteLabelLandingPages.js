import * as pages from './asyncLandingPages.js'

export default {
  AQUILATRACK: {
    component: pages.AsyncDefaultLanding
  },
  PLAIN: {
    component: pages.AsyncPlainLanding
  }
}
