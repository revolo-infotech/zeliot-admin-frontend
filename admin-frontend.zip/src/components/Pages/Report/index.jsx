import React from 'react'

export default function Report() {
  return <div>This is report</div>
}
