export { default } from './DomainConfigError.jsx'
