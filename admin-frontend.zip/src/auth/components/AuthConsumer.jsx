import { Consumer } from '../context'

export default Consumer
