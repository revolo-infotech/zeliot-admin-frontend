#!/bin/sh
docker build -t admin-frontend .
